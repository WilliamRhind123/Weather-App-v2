import PySimpleGUI as sg
import requests
from datetime import datetime
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import socket
import json
import os

# ---------- Theme and Font Persistence Setup ----------
CONFIG_FILE = "config.json"
DEFAULT_THEME = "Dark"
DEFAULT_FONT = "Helvetica"

def load_settings():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
            return data.get("theme", DEFAULT_THEME), data.get("font", DEFAULT_FONT)
    return DEFAULT_THEME, DEFAULT_FONT

def save_settings(theme, font):
    with open(CONFIG_FILE, "w") as f:
        json.dump({"theme": theme, "font": font}, f)

theme, app_font = load_settings()
sg.theme(theme)
# ------------------------------------------------------

App_Cover = "WeatherAppPNG.png"

NewMoon = "icons8-new-moon-96.png"
WaxingCrescent = "icons8-waxing-cresent-moon-96.png" 
FirstQuarter = "icons8-first-quarter-moon-96.png"
WaxingGibbous = "icons8-waxing-gibbous-moon-96.png"
FullMoon = "icons8-full-moon-96.png"
WaningGibbous = "icons8-waning-gibbous-moon-96.png"
LastQuarter = "icons8-last-quarter-moon-96.png"
WaningCrescent = "icons8-waning-crescent-moon-96.png"

def get_moon_image_path(phase_name):
    moon_image_map = {
        "New Moon": NewMoon,
        "Waxing Crescent": WaxingCrescent,
        "First Quarter": FirstQuarter,
        "Waxing Gibbous": WaxingGibbous,
        "Full Moon": FullMoon,
        "Waning Gibbous": WaningGibbous,
        "Last Quarter": LastQuarter,
        "Waning Crescent": WaningCrescent
    }
    return moon_image_map.get(phase_name, "")


def internet_connected(host="8.8.8.8", port=53, timeout=3):
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
        return True
    except socket.error:
        return False

if not internet_connected():
    sg.popup_error("No internet connection detected. Please check your connection and try again.")
    exit()

API_KEY = "db5620faef0a378e1f0a1ac502088363"
Country_Code = ""

def get_moon_phase_name(value):
    if value < 0.0625 or value >= 0.9375:
        return "New Moon"
    elif value < 0.1875:
        return "Waxing Crescent"
    elif value < 0.3125:
        return "First Quarter"
    elif value < 0.4375:
        return "Waxing Gibbous"
    elif value < 0.5625:
        return "Full Moon"
    elif value < 0.6875:
        return "Waning Gibbous"
    elif value < 0.8125:
        return "Last Quarter"
    else:
        return "Waning Crescent"

def get_country_location(country):
    global Country_Code
    api_url = f"http://api.openweathermap.org/geo/1.0/direct?q={country}&limit=1&appid={API_KEY}"
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        sg.popup_error("Network error:", str(e))
        return None, None

    if not data:
        sg.popup_error("Invalid country name or no data found.")
        return None, None

    Country_Code = str(data[0]["country"])
    lat = round(float(data[0]["lat"]), 4)
    lon = round(float(data[0]["lon"]), 4)
    return lat, lon

def fetch_weather_data(lat, lon):
    api_url = (
        f"https://api.openweathermap.org/data/3.0/onecall?"
        f"lat={lat}&lon={lon}&exclude=minutely,alerts&units=metric&appid={API_KEY}"
    )
    response = requests.get(api_url)
    return response.json()

def process_weather_data(data):
    global weekly_sunrise, weekly_sunset, weekly_moonrise, weekly_moonset, weekly_moon_phase, uv_index, feels_like_day, rain_volume, rain_chance, cloud_cover, wind_speed, wind_gust, wind_direction, temp_day
    global hourly_time, hourly_temp, hourly_pop, hourly_clouds, hourly_rain, days_of_week, day_summeries, daily_icons, temp_max, temp_min

    hourly_time = []
    hourly_temp = []
    hourly_pop = []
    hourly_clouds = []
    hourly_rain = []
    days_of_week = [] 
    weekly_sunrise = []
    weekly_sunset = []
    weekly_moonrise = []
    weekly_moonset = []
    weekly_moon_phase = []
    uv_index = []
    feels_like_day = []
    rain_volume = []
    rain_chance = []
    cloud_cover = []
    wind_speed = []
    wind_gust = []
    wind_direction = []
    temp_day = []
    day_summeries = []
    daily_icons = []
    temp_max = []
    temp_min = []

    for day in data["daily"]:
        weekly_sunrise.append(datetime.fromtimestamp(day["sunrise"]).strftime("%I:%M:%S %p"))
        weekly_sunset.append(datetime.fromtimestamp(day["sunset"]).strftime("%I:%M:%S %p"))
        weekly_moonrise.append(datetime.fromtimestamp(day["moonrise"]).strftime("%I:%M:%S %p"))
        weekly_moonset.append(datetime.fromtimestamp(day["moonset"]).strftime("%I:%M:%S %p"))
        weekly_moon_phase.append(get_moon_phase_name(day["moon_phase"]))
        uv_index.append(str(day["uvi"]))
        feels_like_day.append(f"{day['feels_like']['day']}°C")
        rain_volume.append(f"{day['rain'] if 'rain' in day else 0} mm")
        rain_chance.append(f"{int(day['pop'] * 100)}%")
        cloud_cover.append(f"{day['clouds']}%")
        wind_speed.append(f"{day['wind_speed']} m/s")
        wind_gust.append(f"{day['wind_gust'] if 'wind_gust' in day else 0} m/s")
        wind_direction.append(f"{day['wind_deg']}°")
        temp_day.append(f"{day['temp']['day']}°C")
        day_summeries.append(day['summary'] if 'summary' in day else "No summary available.")
        days_of_week.append(datetime.fromtimestamp(day["dt"]).strftime("%A"))
        #daily_icons.append(f"https://openweathermap.org/img/wn/{day['weather'][0]['icon']}@2x.png" if 'weather' in day and len(day['weather']) > 0 else "")
        temp_max.append(f"{day['temp']['max']}°C")
        temp_min.append(f"{day['temp']['min']}°C")

    

    for hour in data["hourly"][:24]:  # Only first 24 hours
        hourly_time.append(datetime.fromtimestamp(hour["dt"]).strftime("%I:%M %p"))
        hourly_temp.append(f"{hour['temp']}°C")
        hourly_pop.append(f"{int(hour['pop'] * 100)}%")
        hourly_clouds.append(f"{hour['clouds']}%")
        hourly_rain.append(f"{hour.get('rain', {}).get('1h', 0)} mm")  # Safe access



def prepare_weather_plot(data, country):
    global weekly_max, weekly_min, day_names
    weekly_max = []
    weekly_min = []
    day_names = []

    for day in data["daily"]:
        weekly_max.append(day["temp"]["max"])
        weekly_min.append(day["temp"]["min"])
        day_names.append(datetime.fromtimestamp(day["dt"]).strftime("%A %d/%B"))

    x_vals = list(range(len(day_names)))

    fig = Figure(figsize=(6, 4))
    ax = fig.add_subplot(111)
    ax.plot(x_vals, weekly_max, marker='o', color='red', label='Max Temp')
    ax.plot(x_vals, weekly_min, marker='o', color='blue', label='Min Temp')
    ax.fill_between(x_vals, weekly_min, color='blue', alpha=0.2)
    ax.fill_between(x_vals, weekly_max, color='red', alpha=0.2)

    ax.set_xticks(x_vals)
    ax.set_xticklabels(day_names, rotation=45)
    ax.set_title(f"Weekly Min/Max Temperature in {country}, {Country_Code}")
    ax.set_ylabel("Temperature (°C)")
    ax.grid(True)
    ax.legend()
    fig.tight_layout()

    return fig

def draw_figure(canvas_elem, figure):
    for child in canvas_elem.winfo_children():
        child.destroy()
    figure_canvas_agg = FigureCanvasTkAgg(figure, canvas_elem)
    figure_canvas_agg.draw()
    figure_canvas_agg.get_tk_widget().pack(side='top', fill='both', expand=1)
    return figure_canvas_agg


# Layouts
Home_layout = [
    [sg.Text("Open Weather Api Weather App", font=(app_font, 20, 'bold'), justification='center', expand_x=True)],
    [sg.Image(filename=App_Cover, size=(600, 600))],
    [sg.Text("Enter City:", font=(app_font, 12)), sg.Input(key="-COUNTRY-"), sg.Button("Get Weather", font=(app_font, 10))]
]

Daily_layout = [
    [sg.Text("7-Day Forecast", font=(app_font, 18, "bold"), justification='center', expand_x=True)],

    # First row with 3 columns
    [
        sg.Column([
            [sg.Text("", key=f"-DAY-{i}-", font=(app_font, 12, "bold"))],
            [sg.Text("", key=f"-MAXMIN-{i}-", font=(app_font, 12))],
            [sg.Text("", key=f"-RAINVOL-{i}-", font=(app_font, 12))],
            [sg.Text("", key=f"-RAINCHANCE-{i}-", font=(app_font, 12))]
        ], pad=(10, 10)) for i in range(3)
    ],

    # Second row with 3 columns
    [
        sg.Column([
            [sg.Text("", key=f"-DAY-{i}-", font=(app_font, 12, "bold"))],
            [sg.Text("", key=f"-MAXMIN-{i}-", font=(app_font, 12))],
            [sg.Text("", key=f"-RAINVOL-{i}-", font=(app_font, 12))],
            [sg.Text("", key=f"-RAINCHANCE-{i}-", font=(app_font, 12))]
        ], pad=(10, 10)) for i in range(3,6)
    ],
    #Last Day
     [
        sg.Column([
            [sg.Text("", key=f"-DAY-{i}-", font=(app_font, 12, "bold"))],
            [sg.Text("", key=f"-MAXMIN-{i}-", font=(app_font, 12))],
            [sg.Text("", key=f"-RAINVOL-{i}-", font=(app_font, 12))],
            [sg.Text("", key=f"-RAINCHANCE-{i}-", font=(app_font, 12))]
        ], pad=(10, 10)) for i in range(6,7)
    ]
]


Graph_layout = [
    [sg.Text("Open Weather Api Weather App", font=(app_font, 20, 'bold'), justification='center', expand_x=True)],
    [sg.Canvas(key='-CANVAS-')],
    [sg.Text("", key="-SUMMARY-", size=(50, 1), font=(app_font, 12))]
]

font_options = ["Helvetica", "Arial", "Courier", "Verdana", "Comic Sans MS"]

Settings_layout = [
    [sg.Text("Choose Theme:", font=(app_font, 12)), sg.Combo(sg.theme_list(), key="-THEME-", readonly=True)],
    [sg.Text("Choose Font:", font=(app_font, 12)), sg.Combo(font_options, key="-FONT-", readonly=True)],
    [sg.Button("Apply Settings", font=(app_font, 10))]
]


Hourly_Fourcast_layout = [
    [sg.Text("Hourly Forecast (Next 24 Hours)", font=(app_font, 14, "bold"))],
    [sg.Table(
        values=[],
        headings=["Time", "Temp", "Rain %", "Cloud %", "Rainfall (mm)"],
        key="-HOUR-TABLE-",
        auto_size_columns=False,
        justification='center',
        col_widths=[14, 14, 14, 14, 17]
    )],
    [sg.Text("Clothing & Activity Recommendations", font=(app_font, 16, "bold"), justification='center', expand_x=True)],
    [sg.Text("Temperature Advice:", font=(app_font, 14))],
    [sg.Text("", key="-RECOMMEND-TEMP-", font=(app_font, 12), size=(60, 2))],
    [sg.Text("UV Advice:", font=(app_font, 14))],
    [sg.Text("", key="-RECOMMEND-UV-", font=(app_font, 12), size=(60, 2))],
    [sg.Text("Rain Advice:", font=(app_font, 14))],
    [sg.Text("", key="-RECOMMEND-RAIN-", font=(app_font, 12), size=(60, 2))]
    
]

Astrology_layout = [
    [sg.Text("Weekly Astrology Info", font=(app_font, 16, "bold"), justification='center', expand_x=True)],
    [sg.Text("Select Day:"), sg.Combo(values=[], key="-ASTRO-DAY-", readonly=True, enable_events=True)],
    [sg.Image(filename="", key="-MOON-IMAGE-", size=(100, 100))],
    [sg.Text("Moon Phase:", font=(app_font, 14)), sg.Text("", key="-ASTRO-MOONPHASE-", font=(app_font, 12))],
    [sg.Text("Sunrise:", font=(app_font, 14)), sg.Text("", key="-ASTRO-SUNRISE-", font=(app_font, 12))],
    [sg.Text("Sunset:", font=(app_font, 14)), sg.Text("", key="-ASTRO-SUNSET-", font=(app_font, 12))],
    [sg.Text("Moonrise:", font=(app_font, 14)), sg.Text("", key="-ASTRO-MOONRISE-", font=(app_font, 12))],
    [sg.Text("Moonset:", font=(app_font, 14)), sg.Text("", key="-ASTRO-MOONSET-", font=(app_font, 12))]
]


layout = [
    [sg.TabGroup([
        [sg.Tab("Weather App", Home_layout)],
        [sg.Tab("Daily", Daily_layout)],
        [sg.Tab("Graph", Graph_layout)],
        [sg.Tab("Hourly Fourcast", Hourly_Fourcast_layout)],
        [sg.Tab("🌙 Astrology", Astrology_layout)],
        [sg.Tab("⚙️ Settings", Settings_layout)],
    ], title_color='black')]
]

# ... [your imports and setup code remain unchanged above this]

window = sg.Window("Weather App", layout, finalize=True, element_justification='center', size=(700, 750))

while True:
    event, values = window.read()
    if event in (sg.WINDOW_CLOSED, "Exit"):
        break

    if event == "Get Weather":
        country = values["-COUNTRY-"].strip()
        if not country:
            sg.popup_error("Please enter a country name.")
            continue
        lat, lon = get_country_location(country)
        if lat is None or lon is None:
            continue
        weather_data = fetch_weather_data(lat, lon)
        process_weather_data(weather_data)

        # Update Graph Tab
        figure = prepare_weather_plot(weather_data, country)
        draw_figure(window["-CANVAS-"].TKCanvas, figure)
        summary_text = f"The temperature peaks at {max(weekly_max)}°C and dips to {min(weekly_min)}°C"
        window["-SUMMARY-"].update(summary_text)

        # Update Hourly Forecast Table
        hourly_values = list(zip(hourly_time, hourly_temp, hourly_pop, hourly_clouds, hourly_rain))
        window["-HOUR-TABLE-"].update(values=hourly_values)

        today_index = 0  # Assuming today is the first in daily list
        today_phase = weekly_moon_phase[today_index]
        window["-ASTRO-MOONPHASE-"].update(today_phase)
        window["-ASTRO-SUNRISE-"].update(weekly_sunrise[today_index])
        window["-ASTRO-SUNSET-"].update(weekly_sunset[today_index])
        window["-ASTRO-MOONRISE-"].update(weekly_moonrise[today_index])
        window["-ASTRO-MOONSET-"].update(weekly_moonset[today_index])

        window["-ASTRO-DAY-"].update(values=days_of_week)
    	#window["-ASTRO-DAY-"].update(set_to_index=0)  # Default to today

        # Set moon image
        moon_image_path = get_moon_image_path(today_phase)
        if os.path.exists(moon_image_path):
            window["-MOON-IMAGE-"].update(filename=moon_image_path)
        else:
            window["-MOON-IMAGE-"].update(filename="")

        current_temp = float(temp_day[0].replace("°C", ""))
        current_uv = float(uv_index[0])
        current_rain_chance = int(rain_chance[0].replace("%", ""))

        # Temperature-based
        if current_temp < 10:
            temp_tip = "Wear a jacket or coat. It's cold outside."
        elif current_temp < 20:
            temp_tip = "A light jacket or hoodie should be fine."
        else:
            temp_tip = "T-shirt and light clothing recommended."

        # UV-based
        if current_uv >= 8:
            uv_tip = "High UV! Wear sunscreen, sunglasses, and a hat."
        elif current_uv >= 5:
            uv_tip = "Moderate UV. Consider sun protection if outdoors long."
        else:
            uv_tip = "Low UV risk. Minimal protection needed."

        # Rain-based
        if current_rain_chance > 70:
            rain_tip = "Carry an umbrella or wear waterproof clothing."
        elif current_rain_chance > 40:
            rain_tip = "Possibly showery—keep an umbrella just in case."
        else:
            rain_tip = "Low chance of rain—enjoy the day!"

        # Update UI
        window["-RECOMMEND-TEMP-"].update(temp_tip)
        window["-RECOMMEND-UV-"].update(uv_tip)
        window["-RECOMMEND-RAIN-"].update(rain_tip)

        for i in range(7):
            window[f"-DAY-{i}-"].update(days_of_week[i])
            window[f"-MAXMIN-{i}-"].update(f"{temp_min[i]} / {temp_max[i]}")
            window[f"-RAINVOL-{i}-"].update(f"Rain: {rain_volume[i]}")
            window[f"-RAINCHANCE-{i}-"].update(f"Chance: {rain_chance[i]}")
            #window[f"-ICON-{i}-"].update(filename=daily_icons[i])

    elif event == "Apply Settings":
        selected_theme = values["-THEME-"]
        selected_font = values["-FONT-"]
        if selected_theme and selected_font:
            save_settings(selected_theme, selected_font)
            sg.popup("Settings saved!\nPlease restart the app to apply the new theme and font.")
    
    elif event == "-ASTRO-DAY-":
        selected_day = values["-ASTRO-DAY-"]
        if selected_day in days_of_week:
            day_index = days_of_week.index(selected_day)
            window["-ASTRO-MOONPHASE-"].update(weekly_moon_phase[day_index])
            window["-ASTRO-SUNRISE-"].update(weekly_sunrise[day_index])
            window["-ASTRO-SUNSET-"].update(weekly_sunset[day_index])
            window["-ASTRO-MOONRISE-"].update(weekly_moonrise[day_index])
            window["-ASTRO-MOONSET-"].update(weekly_moonset[day_index])

        moon_image_path = get_moon_image_path(weekly_moon_phase[day_index])
        if os.path.exists(moon_image_path):
            window["-MOON-IMAGE-"].update(filename=moon_image_path)
        else:
            window["-MOON-IMAGE-"].update(filename="")


window.close()
